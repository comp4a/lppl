 // Ejemplo del uso de operadores logicos
{ int x; int y; bool z=true; 

  while (z) {
    read(x); read(y);
    if ((x != y) || false) {         
      if (!(x == 0) && true)                      
        if ((y >= 0) && (x > 0)) {
	  print(1); z = false;
	}
        else print(0);
      else {}
    } 
    else {}
  }
}
