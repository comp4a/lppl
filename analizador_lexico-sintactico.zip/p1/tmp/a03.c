// Ejemplo de uso de operadores de incremento
{ int a; int b;

  read(a); print(a++); print(a);
  read(a); print(++a); print(a);

  read(a);
  b+=a; print(b); b-=a; print(b);
  b*=a; print(b); b/=a; print(b);
  print (a=b=7); print (a); print (b);
} 
